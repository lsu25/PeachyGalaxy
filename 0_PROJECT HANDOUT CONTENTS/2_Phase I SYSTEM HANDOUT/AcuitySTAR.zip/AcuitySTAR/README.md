# Peachy Galaxy

<img src="https://github.com/zaphodrox/TeamPeachDashboard/blob/master/src/logo.png">

Peachy Galaxy is a helper program used to summarize and organize data from Acuity STAR.
Created by the members of Team Peach, it offers user-friendly tree views and various visualizations of all the data.
