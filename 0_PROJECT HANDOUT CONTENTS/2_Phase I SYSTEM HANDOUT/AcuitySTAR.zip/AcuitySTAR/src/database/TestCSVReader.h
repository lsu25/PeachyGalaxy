#ifndef TESTCSVREADER_H
#define TESTCSVREADER_H

#include <string>
#include <vector>

class TestCSVReader {

public:
    TestCSVReader();
    bool CSV_READER_TEST_01();
    bool CSV_READER_TEST_02();
    bool CSV_READER_TEST_03();
    bool CSV_READER_TEST_04();
    bool CSV_READER_TEST_05();
    bool CSV_READER_TEST_06();
    bool CSV_READER_TEST_07();
    bool CSV_READER_TEST_08();
    void CSV_READER_TEST_ALL();

};

#endif // CSVREADER_H
